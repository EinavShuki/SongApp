package com.example.songsapp;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;


import androidx.annotation.Nullable;

public class AbanibiAvtivity extends Activity {
    EditText c1, c2, c3, c4, c5, c6;
    boolean firstFocus = true;
    boolean l1, l2, l3, l4, l5, l6;
    LinearLayout root;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abanibi);


        root=findViewById(R.id.root);
        c1 = findViewById(R.id.char1);
        c2 = findViewById(R.id.char2);
        c3 = findViewById(R.id.char3);
        c4 = findViewById(R.id.char4);
        c5 = findViewById(R.id.char5);
        c6 = findViewById(R.id.char6);
        Button check = findViewById(R.id.check_btn);
        Button addL = findViewById(R.id.add_letter);
        Button revealSong = findViewById(R.id.reveal);
        Button clear=findViewById(R.id.clear);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c1.setText("");
                c2.setText("");
                c3.setText("");
                c4.setText("");
                c5.setText("");
                c6.setText("");
                l1=l2=l3=l4=l5=l6=false;
            }
        });

        revealSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c1.setText("א");
                c2.setText("ב");
                c3.setText("נ");
                c4.setText("י");
                c5.setText("ב");
                c6.setText("י");

            }
        });

        addL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!l1) {
                    c1.setText("א");
                    l1 = true;
                } else if (!l2) {
                    c2.setText("ב");
                    l2 = true;
                } else if (!l3) {
                    c3.setText("נ");
                    l3 = true;
                } else if (!l4) {
                    c4.setText("י");
                    l4 = true;
                } else if (!l5) {
                    c5.setText("ב");
                    l5 = true;
                } else if (!l6) {
                    c6.setText("י");
                    l6 = true;
                }
            }
        });

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String char1 = c1.getText().toString();
                String char2 = c2.getText().toString();
                String char3 = c3.getText().toString();
                String char4 = c4.getText().toString();
                String char5 = c5.getText().toString();
                String char6 = c6.getText().toString();

                if (char1.equals("א") && char2.equals("ב") && char3.equals("נ") && char4.equals("י") && char5.equals("ב") && char6.equals("י")) {
                    Toast.makeText(AbanibiAvtivity.this, "Vert well!!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AbanibiAvtivity.this, "Try again", Toast.LENGTH_SHORT).show();
                }

            }
        });

        c1.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus && firstFocus) {
                    c1.setText("");
                    firstFocus = false;
                    l1=false;
                }
                if (!hasFocus) {
                    firstFocus = true;
                }
                c1.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() > 0)
                            c2.requestFocus();

                    }
                });

            }
        });
        c2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus && firstFocus) {
                    c2.setText("");
                    firstFocus = false;
                    l2=false;
                }
                if (!hasFocus) {
                    firstFocus = true;
                }
                c2.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() > 0)
                            c3.requestFocus();

                    }
                });
          
            }
        });
        c3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus && firstFocus) {
                    c3.setText("");
                    firstFocus = false;
                    l3=false;
                }
                if (!hasFocus) {
                    firstFocus = true;
                }
                c3.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() > 0)
                            c4.requestFocus();


                    }
                });

            }
        });
        c4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus && firstFocus) {
                    c4.setText("");
                    firstFocus = false;
                    l4=false;
                }
                if (!hasFocus) {
                    firstFocus = true;
                }
                c4.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() > 0)
                            c5.requestFocus();


                    }
                });

            }
        });
        c5.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus && firstFocus) {
                    c5.setText("");
                    firstFocus = false;
                    l5=false;
                }
                if (!hasFocus) {
                    firstFocus = true;
                }
                c5.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        if (s.length() > 0)
                            c6.requestFocus();

                    }

                });

            }
        });
        c6.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus && firstFocus) {
                    l6=false;
                    c6.setText("");
                    firstFocus = false;

                }
                if (!hasFocus) {
                    firstFocus = true;
                }

            }

        });


    }

}
